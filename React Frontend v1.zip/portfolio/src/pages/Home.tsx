import Contact from "./Contact"

export default function Home() {
  return (
    <>
      {/* HERO section */}
      <section className="hero">
        <h1>Weboldal fejlesztés kedvező áron</h1>
        <p>
            <br></br>
           <h2>React</h2> 
            <br></br>
            <h2>TypeScript</h2>
            <br></br>
            <h2>Vite</h2>
            <br></br>
           <h2>Vanilla CSS</h2> 
            <br></br>
            <h2>Node js</h2>
            <br></br>
            <h2>MongoDB
           </h2>
           <br></br>
            <h2>MySQL
           </h2>
            
        </p>

      
      </section>

      {/* Szolgáltatások section */}
      <section className="section">
        <h2>Szolgáltatások</h2>
        <div className="cards">
          <div className="card">
            <h3>Portfólió / CV oldal</h3>
            <p>Modern, egyedi bemutatkozó oldalak vállalkozóknak, vagy álláskeresőknek.</p>
          </div>
          <div className="card">
            <h3>Frontend </h3>
            <p>React,VanillaCSS,Vite,Typescript</p>
          </div>
          <div className="card">
            <h3>Fullstack</h3>
            <p>Fullstack fejlesztés is lehetséges.</p>
          </div>
           <div className="card">
            <h3>Backend </h3>
            <p>NodeJS, MongoDB, MySQL</p>
          </div>
        </div>
      </section>

      
      <Contact />
    </>
  )
}
